#Requires AutoHotkey v2.0

; Only activate these hotstrings inside VS Code
#HotIf WinActive("ahk_exe Code.exe")

:X:@@sqlcreatetable:: {
    A_Clipboard := "CREATE TABLE TableName (`n"
                 . "    ColumnName1 INT IDENTITY(1,1) PRIMARY KEY,`n"
                 . "    ColumnName2 VARCHAR(100) NOT NULL,`n"
                 . "    ColumnName3 DATETIME DEFAULT GETDATE()`n"
                 . ")"
    Sleep(50)
    Send("^v")
}

:X:@@sqladdcol:: {
    A_Clipboard := "ALTER TABLE TableName`n"
                 . "ADD ColumnName DataType(Option) NOT NULL"
    Sleep(50)
    Send("^v")
}

:X:@@sqldropcol:: {
    A_Clipboard := "ALTER TABLE TableName`n"
                 . "DROP COLUMN ColumnName"
    Sleep(50)
    Send("^v")
}

:X:@@sqlinsert:: {
    A_Clipboard := "INSERT INTO TableName(Param1, Param2, ...)`n"
                 . "VALUES`n"
                 . "(Arg1, Arg2, ...),`n"
                 . "(Arg1, Arg2, ...)"
    Sleep(50)
    Send("^v")
}

:X:@@sqlsp:: {
    A_Clipboard := "CREATE PROCEDURE StoredProcedureName`n"
                 . "    @Param1 DataType,`n"
                 . "    @Param2 DataType`n"
                 . "AS`n"
                 . "BEGIN`n"
                 . "    SET NOCOUNT ON;`n"
                 . "    `n"
                 . "END`n`n"
                 . "EXEC StoredProcedureName @Param1 = Arg1, @Param2 = Arg2"
    Sleep(50)
    Send("^v")
}

:X:@@sqlupdatetable:: {
    A_Clipboard := "UPDATE TableName`n"
                 . "SET`n"
                 . "    ColumnName1 = Value1,`n"
                 . "    ColumnName2 = Value2`n"
                 . "WHERE PKColumn = PKValue"
    Sleep(50)
    Send("^v")
}

:X:@@sqldelete:: {
    A_Clipboard := "DELETE FROM TableName`n"
                 . "WHERE PKColumn = PKValue"
    Sleep(50)
    Send("^v")
}

:X:@@serverjs:: {
    A_Clipboard := "const express = require('express');`n"
                 . "const sql = require('mssql');`n"
                 . "const cors = require('cors');`n"
                 . "require('dotenv').config();`n`n"
                 . "const app = express();`n"
                 . "app.use(cors());`n"
                 . "app.use(express.json());`n"
                 . "app.use(express.static('public'));`n`n"
                 . "//config`n"
                 . "const dbConfig = {`n"
                 . "    user: process.env.DB_USER,`n"
                 . "    server: process.env.DB_SERVER,`n"
                 . "    database: process.env.DB_DATABASE,`n"
                 . "    password: process.env.DB_PASS,`n"
                 . "    options: {`n"
                 . "        encrypt: false,`n"
                 . "        trustServerCertificate: true`n"
                 . "    }`n"
                 . "};`n`n"
                 . "//testing`n"
                 . "sql.connect(dbConfig)`n"
                 . "    .then(pool => {`n"
                 . "        if (pool.connecting) console.log('Connecting to MSSQL...');`n"
                 . "        if (pool.connected) console.log('Connected to MSSQL successfully!');`n"
                 . "    })`n"
                 . "    .catch(err => console.error('Database connection failed:', err));`n`n"
                 . "//main`n`n"
                 . "//port listening`n"
                 . "const PORT = process.env.PORT || 5000;`n"
                 . "app.listen(PORT, () => console.log(``Server running on http://localhost:${PORT}``));"
    Sleep(50)
    Send("^v")
}

:X:@@fetchget:: {
    A_Clipboard := "async function get() {`n"
                 . "    try {`n"
                 . "        const url = LOCAL_HOST + 'api/get_data';`n"
                 . "        const res = await fetch(url);`n"
                 . "        if (!res.ok) throw new Error('Network response was not ok');`n"
                 . "        const dataset = await res.json();`n`n"
                 . "        dataset.forEach(s => {`n"
                 . "            `n"
                 . "        });`n"
                 . "    } catch (err) {`n"
                 . "        console.error('Fetch error:', err);`n"
                 . "    }`n"
                 . "}"
    Sleep(50)
    Send("^v")
}

:X:@@fetchpost:: {
    A_Clipboard := "async function post(payload) {`n"
                 . "    try {`n"
                 . "        const url = LOCAL_HOST + 'api/add';`n"
                 . "        const res = await fetch(url, {`n"
                 . "            method: 'POST',`n"
                 . "            headers: {`n"
                 . "                'Content-Type': 'application/json'`n"
                 . "            },`n"
                 . "            body: JSON.stringify(payload)`n"
                 . "        });`n`n"
                 . "        if (!res.ok) throw new Error('Network response was not ok');`n"
                 . "        const result = await res.json();`n"
                 . "    } catch (err) {`n"
                 . "        console.error('Fetch error:', err);`n"
                 . "    }`n"
                 . "}"
    Sleep(50)
    Send("^v")
}

:X:@@apipost:: {
    A_Clipboard := "app.post('/api/add', async (req, res) => {`n"
                 . "    try {`n"
                 . "        const { param1, param2, param3 } = req.body;`n`n"
                 . "        //validate`n"
                 . "        if (!param1 || !param2 || !param3) {`n"
                 . "            return res.status(400).json({ error: 'Missing required fields.' });`n"
                 . "        }`n`n"
                 . "        //params to prevent SQL Injection`n"
                 . "        let pool = await sql.connect();`n"
                 . "        let result = await pool.request()`n"
                 . "            .input('Param1', sql.Int, param1)`n"
                 . "            .input('Param2', sql.VarChar(100), param2)`n"
                 . "            .input('Param3', sql.VarChar(50), param3)`n"
                 . "            .query(`n"
                 . "                EXEC ProcedureName Param1 = @Param1, Param2 = @Param2, Param3 = @Param3;`n"
                 . "            );`n"
                 . "    } catch (err) {`n"
                 . "        console.error('Query error:', err);`n"
                 . "        res.status(500).json({ error: 'Internal Server Error' });`n"
                 . "    }`n"
                 . "});"
    Sleep(50)
    Send("^v")
}

:X:@@apiget:: {
    A_Clipboard := "app.get('/api/get', async (req, res) => {`n"
                 . "    try {`n"
                 . "        const result = await sql.query('EXEC GetStudents');`n"
                 . "        res.json(result.recordset);`n"
                 . "    } catch (err) {`n"
                 . "        res.status(500).json({ error: err.message });`n"
                 . "    }`n"
                 . "});"
    Sleep(50)
    Send("^v")
}

:X:@@htmltitle:: {
    A_Clipboard := "<div class='w3-bar w3-teal w3-card'>`n"
                 . "    <div class='w3-bar-item w3-xlarge w3-wide'>Title</div>`n"
                 . "</div>"
    Sleep(50)
    Send("^v")
}

:X:@@htmlfooter:: {
	A_Clipboard := "<footer class='w3-container w3-teal w3-center w3-padding-16 w3-margin-top'>`n"
					. "	<p>&copy; 2026 Skills Test Students App. All Rights Reserved.</p>`n"
					. "	</footer>"
	Sleep(50)
	Send("^v")
}

:X:@@htmlsearch:: {
	A_Clipboard := "<div class='w3-card w3-white w3-padding w3-margin-bottom'>`n"
					. "<input class='w3-input w3-border' type='text' id='searchInput' placeholder='Search by name...'>`n"
					. "</div>`n"
	Sleep(50)
	Send("^v")
}

:X:@@htmltable:: {
    A_Clipboard := "<div class='w3-card w3-white'>`n"
                 . "    <div class='w3-container w3-teal'>`n"
                 . "        <h3>DirectoryName</h3>`n"
                 . "    </div>`n"
                 . "    <div class='w3-responsive'>`n"
                 . "        <table class='w3-table-all w3-striped w3-hoverable' id='directoryTable'>`n"
                 . "            <thead>`n"
                 . "                <tr class='w3-light-grey'>`n"
                 . "                    <th>ColumnName</th>`n"
                 . "                    <th class='w3-center'>Actions</th>`n"
                 . "                </tr>`n"
                 . "            </thead>`n"
                 . "            <tbody id='tableBody'>`n"
				 . "                <tr><td>TableRow</td><td>TableRow</td></tr>`n"
                 . "            </tbody>`n"
                 . "        </table>`n"
                 . "    </div>`n"
                 . "</div>"
    Sleep(50)
    Send("^v")
}

:X:@@htmlmodal:: {
    A_Clipboard := '<div id="modal" class="w3-modal">`n'
                 . '    <div class="w3-modal-content w3-card-4 w3-animate-top" style="max-width:500px">`n'
                 . '        <header class="w3-container w3-teal">`n'
                 . '            <span onclick="closeModal()" class="w3-button w3-display-topright">&times;</span>`n'
                 . '            <h2 id="modalTitle">Title</h2>`n'
                 . '        </header>`n`n'
                 . '        <div class="w3-container w3-padding-16">`n'
                 . '            <form id="employeeForm" onsubmit="save(event)">`n'
                 . '                <input type="hidden" id="rowId">`n`n'
                 . '                <label class="w3-text-dark-grey"><b>Input1</b></label>`n'
                 . '                <input class="w3-input w3-border w3-margin-bottom" type="text" id="input1" required`n'
                 . '                    placeholder="e.g. Input">`n`n'
                 . '                <label class="w3-text-dark-grey"><b>Select1</b></label>`n'
                 . '                <select class="w3-select w3-border w3-margin-bottom" id="select1" required>`n'
                 . '                    <option value="" disabled selected>Choose option</option>`n'
                 . '                    <option value="option1">Option1</option>`n'
                 . '                    <option value="option2">Option2</option>`n'
                 . '                    <option value="option3">Option3</option>`n'
                 . '                    <option value="option4">Option4</option>`n'
                 . '                </select>`n`n'
                 . '                <div class="w3-section w3-right-align">`n'
                 . '                    <button type="button" class="w3-button w3-red w3-margin-right"`n'
                 . '                        onclick="closeModal()">Cancel</button>`n'
                 . '                    <button type="submit" class="w3-button w3-green">Save</button>`n'
                 . '                </div>`n'
                 . '            </form>`n'
                 . '        </div>`n'
                 . '    </div>`n'
                 . '</div>'
    Sleep(50)
    Send("^v")
}